﻿using System.Collections;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace Huffman;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Compress or decompress? (c/d)");
        string method = Console.ReadLine();

        if (method == "c")
        {
            var data = File.ReadAllText("test.txt");
            var tree = new Tree(data);
            tree.Build();
            var encoded = tree.Encode(data);
            
            int bytes = encoded.Count / 8;
            if ((encoded.Count % 8) != 0) bytes++;
            byte[] arr = new byte[bytes];
            int bitIndex = 0, byteIndex = 0;
            for (int i = 0; i < encoded.Count; i++)
            {
                if (encoded[i])
                {
                    arr[byteIndex] |= (byte)(((byte)1) << bitIndex);
                }
                bitIndex++;
                if (bitIndex == 8)
                {
                    bitIndex = 0;
                    byteIndex++;
                }
            }
            
            File.WriteAllBytes("en.txt", arr);
            File.WriteAllText("fr.txt", JsonSerializer.Serialize(tree.Frequencies));
        }
        else
        {
            var fr = JsonSerializer.Deserialize<Dictionary<char, int>>(File.ReadAllText("fr.txt"));
            var encoded = File.ReadAllBytes("en.txt");
            var bits = new BitArray(encoded);
            var bools = new List<bool>();
            foreach (var bit in bits)
            {
                bools.Add((bool)bit);
            }

            //var encoded = JsonSerializer.Deserialize<List<bool>>(File.ReadAllText("en.txt"));
            var tree = new Tree(fr);
            tree.Build();
            var decoded = tree.Decode(bools);
            Console.WriteLine("Decoded: " + decoded);
        }
    }
}